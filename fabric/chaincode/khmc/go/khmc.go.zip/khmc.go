/*
 SPDX-License-Identifier: Apache-2.0
*/

package main

import (
	"bytes"
	"encoding/json"
	"fmt"

	"github.com/hyperledger/fabric-chaincode-go/shim"
	"github.com/hyperledger/fabric-protos-go/peer"
)

//SmartContract is the data structure which represents this contract and on which  various contract lifecycle functions are attached
type SmartContract struct {
}

type PurchaseOrder struct {
	ObjectType        string `json:"Type"`
	PurchaseOrderNo   string `json:"purchaseOrderNo"`
	PurchaseRequestId string `json:"purchaseRequestId"`
	Date              string `json:"date"`
	Generated         string `json:"generated"`
	GeneratedBy       string `json:"generatedBy"`
	CommentNotes      string `json:"commentNotes"`
	ApprovedBy        string `json:"approvedBy"`
	VendorId          string `json:"vendorId"`
	Status            string `json:"status"`
	CommitteeStatus   string `json:"committeeStatus"`
	CreatedAt         string `json:"createdAt"`
	SentAt            string `json:"sentAt"`
	UpdatedAt         string `json:"updatedAt"`
}

type Item struct {
	ObjectType   string `json:"Type"`
	ItemId       string `json:"itemId"`
	CurrQty      string `json:"currQty"`
	ReqQty       string `json:"reqQty"`
	Comments     string `json:"comments"`
	Name         string `json:"name"`
	Description  string `json:"description"`
	ItemCode     string `json:"itemCode"`
	Istatus      string `json:"istatus"`
	SecondStatus string `json:"secondStatus"`
}

type RItem struct {
	ObjectType   string `json:"Type"`
	ItemId       string `json:"itemId"`
	CurrentQty   string `json:"currentQty"`
	RequestedQty string `json:"requestedQty"`
	RecieptUnit  string `json:"recieptUnit"`
	IssueUnit    string `json:"issueUnit"`
	FuItemCost   string `json:"fuItemCost"`
	Description  string `json:"description"`
	Status       string `json:"status"`
	SecondStatus string `json:"secondStatus"`
}

type PurchaseRequest struct {
	ObjectType      string `json:"Type"`
	RequestNo       string `json:"requestNo"`
	GeneratedBy     string `json:"generatedBy"`
	Status          string `json:"status"`
	CommitteeStatus string `json:"committeeStatus"`
	Availability    string `json:"availability"`
	Reason          string `json:"reason"`
	VendorId        string `json:"vendorId"`
	Rr              string `json:"rr"`
	Item
	RequesterName   string `json:"requesterName"`
	RejectionReason string `json:"rejectionReason"`
	Department      string `json:"department"`
	CommentNotes    string `json:"commentNotes"`
	OrderType       string `json:"orderType"`
	Generated       string `json:"generated"`
	ApprovedBy      string `json:"approvedBy"`
	CreatedAt       string `json:"createdAt"`
	UpdatedAt       string `json:"updatedAt"`
}

type Patient struct {
	ObjectType string `json:"Type"`
	PatientID  string `json:"patientID"`
	Name       string `json:"name"`
	Age        string `json:"age"`
	Gender     string `json:"gender"`
}

type ReplenishmentRequest struct {
	ObjectType    string `json:"Type"`
	RequestNo     string `json:"requestNo"`
	Generated     string `json:"generated"`
	GeneratedBy   string `json:"generatedBy"`
	DateGenerated string `json:"dateGenerated"`
	Reason        string `json:"reason"`
	FuId          string `json:"fuId"`
	To            string `json:"to"`
	From          string `json:"from"`
	Comments      string `json:"comments"`
	RItem
	Status        string `json:"status"`
	SecondStatus  string `json:"secondStatus"`
	RrB           string `json:"rrB"`
	ApprovedBy    string `json:"approvedBy"`
	RequesterName string `json:"requesterName"`
	OrderType     string `json:"orderType"`
	Department    string `json:"department"`
	CommentNote   string `json:"commentNote"`
	CreatedAt     string `json:"createdAt"`
	UpdatedAt     string `json:"updatedAt"`
}

type FunctionalUnit struct {
	ObjectType  string `json:"Type"`
	Uuid        string `json:"uuid"`
	FuName      string `json:"fuName"`
	Description string `json:"description"`
	FuHead      string `json:"fuHead"`
	Status      string `json:"status"`
	BuId        string `json:"buId"`
	FuLogId     string `json:"fuLogId"`
	CreatedAt   string `json:"createdAt"`
	UpdatedAt   string `json:"updatedAt"`
}

type FuInventory struct {
	ObjectType   string `json:"Type"`
	FuId         string `json:"fuId"`
	ItemId       string `json:"itemId"`
	Qty          string `json:"qty"`
	MaximumLevel string `json:"maximumLevel"`
	ReorderLevel string `json:"reorderLevel"`
	MinimumLevel string `json:"minimumLevel"`
	CreatedAt    string `json:"createdAt"`
	UpdatedAt    string `json:"updatedAt"`
	BatchArray   
	TempBatchArray
}

type BatchArray []struct {
	ObjectType  string `json:"Type"`
	BatchNumber string `json:"batchNumber"`
	ExpiryDate  string `json:"expiryDate"`
	Quantity    string `json:"quantity"`
}

type TempBatchArray []struct {
	ObjectType  string `json:"Type"`
	BatchNumber string `json:"batchNumber"`
	ExpiryDate  string `json:"expiryDate"`
	Quantity    string `json:"quantity"`
}

func (t *SmartContract) Init(stub shim.ChaincodeStubInterface) peer.Response {

	fmt.Println("Init Firing!")
	return shim.Success(nil)
}

func (t *SmartContract) Invoke(stub shim.ChaincodeStubInterface) peer.Response {

	// Retrieve the requested Smart Contract function and arguments
	function, args := stub.GetFunctionAndParameters()
	fmt.Println("Chaincode Invoke Is Running " + function)
	if function == "addPurchaseOrder" {
		return t.addPurchaseOrder(stub, args)
	}
	if function == "addPurchaseRequest" {
		return t.addPurchaseRequest(stub, args)
	}
	if function == "queryPatientByName" {
		return t.queryPatientByName(stub, args)
	}
	if function == "queryPurchaseOrder" {
		return t.queryPurchaseOrder(stub, args)
	}
	if function == "queryPurchaseRequest" {
		return t.queryPurchaseRequest(stub, args)
	}
	if function == "addPatient" {
		return t.addPatient(stub, args)
	}
	if function == "queryPatient" {
		return t.queryPatient(stub, args)
	}
	if function == "queryPatientByName" {
		return t.queryPatientByName(stub, args)
	}
	if function == "addReplenishmentRequest" {
		return t.addReplenishmentRequest(stub, args)
	}
	if function == "queryReplenishmentRequest" {
		return t.queryReplenishmentRequest(stub, args)
	}
	if function == "addFunctionalUnit" {
		return t.addFunctionalUnit(stub, args)
	}
	if function == "queryFunctionalUnit" {
		return t.queryFunctionalUnit(stub, args)
	}

	fmt.Println("Invoke did not find specified function " + function)
	return shim.Error("Invoke did not find specified function " + function)
}

func (t *SmartContract) addPurchaseOrder(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 13 {
		return shim.Error("Incorrect Number of Aruments. Expecting 8")
	}

	fmt.Println("Adding new PurchaseOrder")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th Argument Must be a Non-Empty String")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th Argument Must be a Non-Empty String")
	}
	if len(args[6]) <= 0 {
		return shim.Error("7th Argument Must be a Non-Empty String")
	}
	if len(args[7]) <= 0 {
		return shim.Error("8th Argument Must be a Non-Empty String")
	}
	if len(args[8]) <= 0 {
		return shim.Error("9th Argument Must be a Non-Empty String")
	}
	if len(args[9]) <= 0 {
		return shim.Error("10th Argument Must be a Non-Empty String")
	}
	if len(args[10]) <= 0 {
		return shim.Error("11th Argument Must be a Non-Empty String")
	}
	if len(args[11]) <= 0 {
		return shim.Error("12th Argument Must be a Non-Empty String")
	}
	if len(args[12]) <= 0 {
		return shim.Error("13th Argument Must be a Non-Empty String")
	}

	purchaseOrderNo := args[0]
	purchaseRequestId := args[1]
	date := args[2]
	generated := args[3]
	generatedBy := args[4]
	commentNotes := args[5]
	approvedBy := args[6]
	vendorId := args[7]
	status := args[8]
	committeeStatus := args[9]
	createdAt := args[10]
	sentAt := args[11]
	updatedAt := args[12]

	// ======Check if PurchaseOrder Already exists

	PurchaseOrderAsBytes, err := stub.GetState(purchaseOrderNo)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if PurchaseOrderAsBytes != nil {
		return shim.Error("The Inserted PurchaseOrder ID already Exists: " + purchaseOrderNo)
	}

	// ===== Create PurchaseOrder Object and Marshal to JSON

	objectType := "PurchaseOrder"
	PurchaseOrder := &PurchaseOrder{objectType, purchaseOrderNo, purchaseRequestId, date, generated, generatedBy, commentNotes, approvedBy, vendorId, status, committeeStatus, createdAt, sentAt, updatedAt}
	PurchaseOrderJSONasBytes, err := json.Marshal(PurchaseOrder)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save PurchaseOrder to State

	err = stub.PutState(purchaseOrderNo, PurchaseOrderJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved PurchaseOrder")
	return shim.Success(nil)
}

func (t *SmartContract) queryPurchaseOrder(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	purchaseOrderNo := args[0]

	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"PurchaseOrder\",\"purchaseOrderNo\":\"%s\"}}", purchaseOrderNo)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) addPurchaseRequest(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 26 {
		return shim.Error("Incorrect Number of Arguments. Expecting 19")
	}

	fmt.Println("Adding new PurchaseOrder")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th Argument Must be a Non-Empty String")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th Argument Must be a Non-Empty String")
	}
	if len(args[6]) <= 0 {
		return shim.Error("7th Argument Must be a Non-Empty String")
	}
	if len(args[7]) <= 0 {
		return shim.Error("8th Argument Must be a Non-Empty String")
	}
	if len(args[8]) <= 0 {
		return shim.Error("9th Argument Must be a Non-Empty String")
	}
	if len(args[9]) <= 0 {
		return shim.Error("10th Argument Must be a Non-Empty String")
	}
	if len(args[10]) <= 0 {
		return shim.Error("11th Argument Must be a Non-Empty String")
	}
	if len(args[11]) <= 0 {
		return shim.Error("12th Argument Must be a Non-Empty String")
	}
	if len(args[12]) <= 0 {
		return shim.Error("13th Argument Must be a Non-Empty String")
	}
	if len(args[13]) <= 0 {
		return shim.Error("14th Argument Must be a Non-Empty String")
	}
	if len(args[14]) <= 0 {
		return shim.Error("15th Argument Must be a Non-Empty String")
	}
	if len(args[15]) <= 0 {
		return shim.Error("16th Argument Must be a Non-Empty String")
	}
	if len(args[16]) <= 0 {
		return shim.Error("17th Argument Must be a Non-Empty String")
	}
	if len(args[17]) <= 0 {
		return shim.Error("18th Argument Must be a Non-Empty String")
	}
	if len(args[18]) <= 0 {
		return shim.Error("19th Argument Must be a Non-Empty String")
	}
	if len(args[19]) <= 0 {
		return shim.Error("20th Argument Must be a Non-Empty String")
	}
	if len(args[20]) <= 0 {
		return shim.Error("21th Argument Must be a Non-Empty String")
	}
	if len(args[21]) <= 0 {
		return shim.Error("22th Argument Must be a Non-Empty String")
	}
	if len(args[22]) <= 0 {
		return shim.Error("23th Argument Must be a Non-Empty String")
	}
	if len(args[23]) <= 0 {
		return shim.Error("24th Argument Must be a Non-Empty String")
	}
	if len(args[24]) <= 0 {
		return shim.Error("25th Argument Must be a Non-Empty String")
	}
	if len(args[25]) <= 0 {
		return shim.Error("26th Argument Must be a Non-Empty String")
	}

	requestNo := args[0]
	generatedBy := args[1]
	status := args[2]
	committeeStatus := args[3]
	availability := args[4]
	reason := args[5]
	vendorId := args[6]
	rr := args[7]
	itemId := args[8]
	currQty := args[9]
	reqQty := args[10]
	comments := args[11]
	name := args[12]
	description := args[13]
	itemCode := args[14]
	istatus := args[15]
	secondStatus := args[16]
	requesterName := args[17]
	rejectionReason := args[18]
	department := args[19]
	commentNotes := args[20]
	orderType := args[21]
	generated := args[22]
	approvedBy := args[23]
	createdAt := args[24]
	updatedAt := args[25]

	// ======Check if PurchaseRequest Already exists

	PurchaseRequestAsBytes, err := stub.GetState(requestNo)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if PurchaseRequestAsBytes != nil {
		return shim.Error("The Inserted PurchaseOrder ID already Exists: " + requestNo)
	}

	// ===== Create Item Object and Marshal to JSON

	objectType := "PurchaseRequest"
	object := "Item"
	PurchaseRequest := &PurchaseRequest{objectType, requestNo, generatedBy, status, committeeStatus, availability, reason, vendorId, rr, Item{object, itemId, currQty, reqQty, comments, name, description, itemCode, istatus, secondStatus}, requesterName, rejectionReason, department, commentNotes, orderType, generated, approvedBy, createdAt, updatedAt}
	PurchaseRequestJSONasBytes, err := json.Marshal(PurchaseRequest)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save PurchaseRequest to State

	err = stub.PutState(requestNo, PurchaseRequestJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved PurchaseRequest")
	return shim.Success(nil)
}

func (t *SmartContract) addReplenishmentRequest(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 28 {
		return shim.Error("Incorrect Number of Arguments. Expecting 19")
	}

	fmt.Println("Adding new PurchaseOrder")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th Argument Must be a Non-Empty String")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th Argument Must be a Non-Empty String")
	}
	if len(args[6]) <= 0 {
		return shim.Error("7th Argument Must be a Non-Empty String")
	}
	if len(args[7]) <= 0 {
		return shim.Error("8th Argument Must be a Non-Empty String")
	}
	if len(args[8]) <= 0 {
		return shim.Error("9th Argument Must be a Non-Empty String")
	}
	if len(args[9]) <= 0 {
		return shim.Error("10th Argument Must be a Non-Empty String")
	}
	if len(args[10]) <= 0 {
		return shim.Error("11th Argument Must be a Non-Empty String")
	}
	if len(args[11]) <= 0 {
		return shim.Error("12th Argument Must be a Non-Empty String")
	}
	if len(args[12]) <= 0 {
		return shim.Error("13th Argument Must be a Non-Empty String")
	}
	if len(args[13]) <= 0 {
		return shim.Error("14th Argument Must be a Non-Empty String")
	}
	if len(args[14]) <= 0 {
		return shim.Error("15th Argument Must be a Non-Empty String")
	}
	if len(args[15]) <= 0 {
		return shim.Error("16th Argument Must be a Non-Empty String")
	}
	if len(args[16]) <= 0 {
		return shim.Error("17th Argument Must be a Non-Empty String")
	}
	if len(args[17]) <= 0 {
		return shim.Error("18th Argument Must be a Non-Empty String")
	}
	if len(args[18]) <= 0 {
		return shim.Error("19th Argument Must be a Non-Empty String")
	}
	if len(args[19]) <= 0 {
		return shim.Error("20th Argument Must be a Non-Empty String")
	}
	if len(args[20]) <= 0 {
		return shim.Error("21th Argument Must be a Non-Empty String")
	}
	if len(args[21]) <= 0 {
		return shim.Error("22th Argument Must be a Non-Empty String")
	}
	if len(args[22]) <= 0 {
		return shim.Error("23th Argument Must be a Non-Empty String")
	}
	if len(args[23]) <= 0 {
		return shim.Error("24th Argument Must be a Non-Empty String")
	}
	if len(args[24]) <= 0 {
		return shim.Error("25th Argument Must be a Non-Empty String")
	}
	if len(args[25]) <= 0 {
		return shim.Error("26th Argument Must be a Non-Empty String")
	}
	if len(args[26]) <= 0 {
		return shim.Error("27th Argument Must be a Non-Empty String")
	}
	if len(args[27]) <= 0 {
		return shim.Error("28th Argument Must be a Non-Empty String")
	}

	requestNo := args[0]
	generated := args[1]
	generatedBy := args[2]
	dateGenerated := args[3]
	reason := args[4]
	fuId := args[5]
	to := args[6]
	from := args[7]
	comments := args[8]
	itemId := args[9]
	currentQty := args[10]
	requestedQty := args[11]
	recieptUnit := args[12]
	issueUnit := args[13]
	fuItemCost := args[14]
	description := args[15]
	rstatus := args[16]
	rsecondStatus := args[17]
	status := args[18]
	secondStatus := args[19]
	rrB := args[20]
	approvedBy := args[21]
	requesterName := args[22]
	orderType := args[23]
	department := args[24]
	commentNote := args[25]
	createdAt := args[26]
	updatedAt := args[27]

	// ======Check if PurchaseRequest Already exists

	replenishmentRequestAsBytes, err := stub.GetState(requestNo)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if replenishmentRequestAsBytes != nil {
		return shim.Error("The Inserted replenishmentRequest ID already Exists: " + requestNo)
	}

	// ===== Create Item Object and Marshal to JSON

	objectType := "ReplenishmentRequest"
	object := "RItem"
	ReplenishmentRequest := &ReplenishmentRequest{objectType, requestNo, generated, generatedBy, dateGenerated, reason, fuId, to, from, comments, RItem{object, itemId, currentQty, requestedQty, recieptUnit, issueUnit, fuItemCost, description, rstatus, rsecondStatus}, status, secondStatus, rrB, approvedBy, requesterName, orderType, department, commentNote, createdAt, updatedAt}
	ReplenishmentRequestJSONasBytes, err := json.Marshal(ReplenishmentRequest)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save replenishmentRequest to State

	err = stub.PutState(requestNo, ReplenishmentRequestJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved ReplenishmentRequest")
	return shim.Success(nil)
}

func (t *SmartContract) queryReplenishmentRequest(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	requestNo := args[0]
	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"ReplenishmentRequest\",\"requestNo\":\"%s\"}}", requestNo)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) queryPurchaseRequest(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	requestNo := args[0]
	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"PurchaseRequest\",\"requestNo\":\"%s\"}}", requestNo)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) addPatient(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 8 {
		return shim.Error("Incorrect Number of Aruments. Expecting 8")
	}

	fmt.Println("Adding new Patient")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}

	patientID := args[0]
	name := args[1]
	age := args[2]
	gender := args[3]

	// ======Check if Patient Already exists

	patientAsBytes, err := stub.GetState(patientID)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if patientAsBytes != nil {
		return shim.Error("The Inserted Patient ID already Exists: " + patientID)
	}

	// ===== Create Patient Object and Marshal to JSON

	objectType := "Patient"
	Patient := &Patient{objectType, patientID, name, age, gender}
	PatientJSONasBytes, err := json.Marshal(Patient)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save Patient to State

	err = stub.PutState(patientID, PatientJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved Patient")
	return shim.Success(nil)
}

func (t *SmartContract) queryPatient(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	patientID := args[0]

	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"Patient\",\"patientID\":\"%s\"}}", patientID)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) queryPatientByName(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	name := args[0]

	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"Patient\",\"name\":\"%s\"}}", name)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) addFunctionalUnit(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 9 {
		return shim.Error("Incorrect Number of Aruments. Expecting 8")
	}

	fmt.Println("Adding new FunctionalUnit")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th Argument Must be a Non-Empty String")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th Argument Must be a Non-Empty String")
	}
	if len(args[6]) <= 0 {
		return shim.Error("7th Argument Must be a Non-Empty String")
	}
	if len(args[7]) <= 0 {
		return shim.Error("8th Argument Must be a Non-Empty String")
	}
	if len(args[8]) <= 0 {
		return shim.Error("9th Argument Must be a Non-Empty String")
	}

	uuid := args[0]
	fuName := args[1]
	description := args[2]
	fuHead := args[3]
	status := args[4]
	buId := args[5]
	fuLogId := args[6]
	createdAt := args[7]
	updatedAt := args[8]

	// ======Check if FunctionalUnit Already exists

	FunctionalUnitAsBytes, err := stub.GetState(uuid)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if FunctionalUnitAsBytes != nil {
		return shim.Error("The Inserted FunctionalUnit ID already Exists: " + uuid)
	}

	// ===== Create FunctionalUnit Object and Marshal to JSON

	objectType := "FunctionalUnit"
	FunctionalUnit := &FunctionalUnit{objectType, uuid, fuName, description, fuHead, status, buId, fuLogId, createdAt, updatedAt}
	FunctionalUnitJSONasBytes, err := json.Marshal(FunctionalUnit)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save FunctionalUnit to State

	err = stub.PutState(uuid, FunctionalUnitJSONasBytes)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved FunctionalUnit")
	return shim.Success(nil)
}

func (t *SmartContract) queryFunctionalUnit(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	if len(args) < 1 {
		return shim.Error("Incorrect number of arguments. Expecting 1")
	}

	uuid := args[0]

	queryString := fmt.Sprintf("{\"selector\":{\"Type\":\"FunctionalUnit\",\"uuid\":\"%s\"}}", uuid)

	queryResults, err := getQueryResultForQueryString(stub, queryString)
	if err != nil {
		return shim.Error(err.Error())
	}

	return shim.Success(queryResults)
}

func (t *SmartContract) addFuInventory(stub shim.ChaincodeStubInterface, args []string) peer.Response {

	var err error

	if len(args) != 14 {
		return shim.Error("Incorrect Number of Aruments. Expecting 14")
	}

	fmt.Println("Adding new FuInventory")

	// ==== Input sanitation ====
	if len(args[0]) <= 0 {
		return shim.Error("1st Argument Must be a Non-Empty String")
	}
	if len(args[1]) <= 0 {
		return shim.Error("2nd Argument Must be a Non-Empty String")
	}
	if len(args[2]) <= 0 {
		return shim.Error("3rd Argument Must be a Non-Empty String")
	}
	if len(args[3]) <= 0 {
		return shim.Error("4th Argument Must be a Non-Empty String")
	}
	if len(args[4]) <= 0 {
		return shim.Error("5th Argument Must be a Non-Empty String")
	}
	if len(args[5]) <= 0 {
		return shim.Error("6th Argument Must be a Non-Empty String")
	}
	if len(args[6]) <= 0 {
		return shim.Error("7th Argument Must be a Non-Empty String")
	}
	if len(args[7]) <= 0 {
		return shim.Error("8th Argument Must be a Non-Empty String")
	}
	if len(args[8]) <= 0 {
		return shim.Error("9th Argument Must be a Non-Empty String")
	}

	fuId := args[0]
	itemId := args[1]
	qty := args[2]
	maximumLevel := args[3]
	reorderLevel := args[4]
	minimumLevel := args[5]
	createdAt := args[6]
	updatedAt := args[7]
	batchNumber := args[8]
	expiryDate := args[9]
	quantity := args[10]
	tempbatchNumber := args[11]
	tempexpiryDate := args[12]
	tempquantity := args[13]

	// ======Check if FuInventory Already exists

	FuInventoryAsBytes, err := stub.GetState(fuId)
	if err != nil {
		return shim.Error("Transaction Failed with Error: " + err.Error())
	} else if FuInventoryAsBytes != nil {
		return shim.Error("The Inserted FuInventory ID already Exists: " + fuId)
	}

	// ===== Create FuInventory Object and Marshal to JSON

	objectType := "FuInventory"
	object := "batchArray"
	tempObject := "tempBatchArray"
	FuInventory := &FuInventory{objectType, fuId, itemId, qty, maximumLevel, reorderLevel, minimumLevel, createdAt, updatedAt, BatchArray{[object][batchNumber][batchNumber][expiryDate][quantity]}}
	FuInventoryJSONasBytes, err := json.Marshal(FuInventory)

	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Save FuInventory to State

	err = stub.PutState(fuId, FuInventory)
	if err != nil {
		return shim.Error(err.Error())
	}

	// ======= Return Success

	fmt.Println("Successfully Saved FuInventory")
	return shim.Success(nil)
}

func getQueryResultForQueryString(stub shim.ChaincodeStubInterface, queryString string) ([]byte, error) {

	fmt.Printf("- getQueryResultForQueryString queryString:\n%s\n", queryString)

	resultsIterator, err := stub.GetQueryResult(queryString)
	if err != nil {
		return nil, err
	}
	defer resultsIterator.Close()

	// buffer is a JSON array containing QueryRecords
	var buffer bytes.Buffer
	buffer.WriteString("[")

	bArrayMemberAlreadyWritten := false
	for resultsIterator.HasNext() {
		queryResponse, err := resultsIterator.Next()
		if err != nil {
			return nil, err
		}
		// Add a comma before array members, suppress it for the first array member
		if bArrayMemberAlreadyWritten == true {
			buffer.WriteString(",")
		}
		buffer.WriteString("{\"Key\":")
		buffer.WriteString("\"")
		buffer.WriteString(queryResponse.Key)
		buffer.WriteString("\"")

		buffer.WriteString(", \"Record\":")
		// Record is a JSON object, so we write as-is
		buffer.WriteString(string(queryResponse.Value))
		buffer.WriteString("}")
		bArrayMemberAlreadyWritten = true
	}
	buffer.WriteString("]")

	fmt.Printf("- getQueryResultForQueryString queryResult:\n%s\n", buffer.String())

	return buffer.Bytes(), nil
}

//Main Function starts up the Chaincode
func main() {
	err := shim.Start(new(SmartContract))
	if err != nil {
		fmt.Printf("Smart Contract could not be run. Error Occured: %s", err)
	} else {
		fmt.Println("Smart Contract successfully Initiated")
	}
}
